const xapi = require('xapi');

const ZOOMSPEED_DIAL_NUMBER = '1@zoomcrc.com';

xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
    if(event.PanelId == 'oneTouchZoomDial_PID'){
         xapi.command("dial", {Number: ZOOMSPEED_DIAL_NUMBER});
    }
});